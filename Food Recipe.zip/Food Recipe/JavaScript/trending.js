document
  .getElementById("viewRecipeButton1")
  .addEventListener("click", function () {
    window.location.href = "Doro.html";
  });

document
  .getElementById("viewRecipeButton2")
  .addEventListener("click", function () {
    window.location.href = "Fufuhtml";
  });

document
  .getElementById("viewRecipeButton3")
  .addEventListener("click", function () {
    window.location.href = "sambusa.html";
  });

document
  .getElementById("viewRecipeButton4")
  .addEventListener("click", function () {
    window.location.href = "pizza.html";
  });
